# NutriSafe — local functional prototype

A Flask + SQLite starter application aligned to the uploaded NutriSafe manuscript. It includes dashboard, pupil records, allergy profiles, menu records and rule-based conflict screening, attendance, rule-based meal candidate suggestions, basic attendance-history meal forecasting, inventory, CSV reports, user roles, and audit events.

## Run on Windows
1. Install Python 3.10 or newer.
2. Extract this folder.
3. Double-click `run_windows.bat`, or run:
   ```
   python -m venv .venv
   .venv\\Scripts\\activate
   pip install -r requirements.txt
   python app.py
   ```
4. Open http://127.0.0.1:5000

## Demo accounts (sample only)
- admin / NutriSafe123!
- coordinator / NutriSafe123!
- nurse / NutriSafe123!
- teacher / NutriSafe123!

## Important limitations before real school use
- This is a local prototype, not a production-ready system. It uses SQLite and plain-text demo passwords to keep setup simple. Do not enter real pupil/health data. Before deployment, implement password hashing, CSRF protection, secure session/cookie settings, HTTPS, backups, stronger audit controls, and a privacy/security review.
- Allergy checks use simple keyword matching for four configured demo allergen terms: peanut, egg, milk, wheat. This is not a medical classifier, may miss ingredient synonyms/hidden ingredients, and must never be treated as proof a meal is safe. Have authorized staff verify labels and ingredient sources.
- Recommendations use sample menu choices and rule matching only; they are not clinical or vitamin prescriptions.
- Forecasting uses a simple historical attendance average as a working baseline, not the manuscript's full Holt-Winters/ARIMA implementation. Validate it against actual data before relying on it.
- Demo pupil and inventory records are explicitly sample data. Remove them before any real deployment.
- The manuscript mentions Firebase Firestore and a React/Tailwind + Node/Express architecture. This starter uses Flask/SQLite for local testability and would need integration work to match that production stack exactly.
